$(document).ready(function() {

  //Mobile Nav
  $('#bars,#close').click(function() {
    $('#bars,#close').toggle();
    $('.nav-bar #menu').toggleClass('visible');
  });

});
